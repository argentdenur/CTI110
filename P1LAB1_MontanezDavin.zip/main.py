first_name = input()
print('Hello', first_name, 'and welcome to CS Online!')
''' Type your code here. '''